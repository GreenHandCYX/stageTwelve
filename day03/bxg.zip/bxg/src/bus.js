//用于组件间传值
import Vue from 'vue'
export default new Vue({})